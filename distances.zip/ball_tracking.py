# Single Color RGB565 Blob Tracking Example
#
# This example shows off single color RGB565 tracking using the OpenMV Cam.

import sensor, image, time, math,struct,lcd
from pyb import UART
from pyb import LED
from pyb import Pin


p_in = Pin('P1', Pin.IN, Pin.PULL_DOWN)#设置p_in为输入引脚，并开启上拉电阻

# Color Tracking Thresholds (L Min, L Max, A Min, A Max, B Min, B Max)
# The below thresholds track in general red/green/blue things. You may wish to tune them...

K=17.3*250#the value should be measured

thresholds = [(0, 100, 37, 82, 75, -38)]
sum=0
sensor.reset()

sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 1000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking
#sensor.set_auto_exposure(False,1500)
lcd.init()

clock = time.clock()

list=[]
led1=LED(1)
led2=LED(2)
uart = UART(3,115200)  #串口3，波特率115200
# Only blobs that with more pixels than "pixel_threshold" and more area than "area_threshold" are
# returned by "find_blobs" below. Change "pixels_threshold" and "area_threshold" if you change the
# camera resolution. "merge=True" merges all overlapping blobs in the image.
#数据打包
def send_data_packet(x, L):
    temp = struct.pack(">bHHb",                #格式为俩个字符俩个整型
                   0xAA,                       #帧头1
                   int(x), # up sample by 4    #数据1
                   int(L), # up sample by 4    #数据3
                   0xAE)                       #帧头2
    uart.write(temp)
#打包距离数据
#def send_data_packet1(L):
    #temp = struct.pack(">bHb",                #格式为俩个字符俩个整型
                   #0xAA,                       #帧头1
                   #int(L), # up sample by 4    #数据1
                   #0xAE)                       #帧头2
    #uart.write(temp)


#计算平均值(可变参数)
def avg_numberic(a, *args):
    L=(a + sum(args)) / (len(args) + 1)
    return L


#找到最大色块
def find_max(blobs):
    max_size=0
    for blob in blobs:
        if blob.pixels() > max_size:
            max_blob=blob
            max_size = blob.pixels()
    return max_blob


while(True):
    clock.tick()
    img = sensor.snapshot()
    value = p_in.value()  # get value, 0 or 1#读入p_in引脚的值
    #img.draw_cross(160, 120, color = (255,255,255), size = 30, thickness = 1)
    blobs=img.find_blobs([thresholds[0]],pixels_threshold=60, area_threshold=60, merge=True)
    #print("3 ",blobs )
    if blobs==[]:
        led2.off()#灭
        send_data_packet(888,888)
    if blobs:
        max_blob=find_max(blobs)
        b=blobs[0]
        led2.on()#亮
        Lm = (b[2] + b[3]) / 2
        length = K / Lm
        print("像素1：",Lm)
        print("距离：",length)
        #img.draw_rectangle(b[0:4]) # rect
        #img.draw_cross(b[5], b[6]) # cx, c
        #img.draw_rectangle(max_blob.rect())
        #img.draw_cross(max_blob.cx(), max_blob.cy())
        send_data_packet(max_blob.cx(),length)
        print(max_blob.cx(), max_blob.cy())


    #lcd.display(sensor.snapshot())
    #if
    #img.draw_cross(160, 120, color = (255,255,255), size = 30, thickness = 1)
    #print(clock.fps())
